package dev.overgrown.apoli.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.overgrown.apoli.Apoli;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class ApoliClientConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static ApoliClientConfig instance;

    private boolean speechToAction = false;

    public boolean speechToAction() {
        return speechToAction;
    }

    public void setSpeechToAction(boolean value) {
        speechToAction = value;
        save();
    }

    public static ApoliClientConfig get() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("apoli-client.json");
    }

    private static ApoliClientConfig load() {
        Path path = path();
        try {
            if (Files.exists(path)) {
                ApoliClientConfig loaded = GSON.fromJson(Files.readString(path), ApoliClientConfig.class);
                if (loaded != null) {
                    return loaded;
                }
            }
        } catch (Exception e) {
            Apoli.LOGGER.warn("[Apoli] Failed to read apoli-client.json, using defaults", e);
        }
        ApoliClientConfig fresh = new ApoliClientConfig();
        fresh.save();
        return fresh;
    }

    private void save() {
        try {
            Files.writeString(path(), GSON.toJson(this));
        } catch (Exception e) {
            Apoli.LOGGER.warn("[Apoli] Failed to write apoli-client.json", e);
        }
    }
}
